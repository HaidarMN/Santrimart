<?php
session_start();
error_reporting(0);

include '../inc/koneksi.php';

if (isset($_POST['submit'])) {
    $_SESSION['submit'] = '';
}

print_r($_SESSION);
if (isset($_POST['submit'])) {
    if ($_POST["kode"] != $_SESSION["tiket_cap"] or $_SESSION["tiket_cap"] == '') {
        echo "<script>alert('Incorrect verification code');</script>";
    } else {
        $nama = $_POST['nama'];
        $noTelp = $_POST['noTelp'];
        $story = $_POST['story'];
        $date = date('Y-m-d H:i:s');
        // print_r($nama, $noTelp, $story, $date);


        // $comment = "INSERT INTO 'tabel_comment' ('nama', 'no_telepon', 'story', 'date')  VALUES ('$nama', 
        // '$noTelp','$story','$date')";
        $comment = "INSERT INTO tabel_comment values('','$nama','$noTelp','$story','$date')";


        // print_r($koneksi);

        if (mysqli_query($koneksi, $comment)) {
            // $message = "komentar telah diterima";


            if (isset($_SERVER["HTTP_REFERER"])) {
                echo "<script>alert('Incorrect verification code');</script>";
                header("Location: " . $_SERVER["HTTP_REFERER"]);
                // echo "<script type='text/javascript'>alert('Transaksi Sukses');window.location.href='../page/index.php?menu=home';</script>";
                // echo("<script>alert('file successful deleted!')</script>");
                // echo("<script>window.location = 'home.php';</script>");
            }


            // print_r($comment);
            // echo nl2br("\n$first_name\n $last_name\n "
            //     . "$gender\n $address\n $email");
        } else {
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
    }
}
