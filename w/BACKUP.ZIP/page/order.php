<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-9 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="col-12">
                        <h2 class="content-header-title float-left mb-0 text-dark text-capitalize">
                            <?php echo $_SESSION['akses']; ?></h2>
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php?menu=home" class="text-dark">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a href="#" class="text-dark">Order</a>
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="divider">
                    <div class="divider-text">
                        <h3 class="mb-3 display-4 text-uppercase">ORDER</h3>
                    </div>
                </div>

                <div class="col-lg-12 col-12">
                    <div class="badge badge-primary float-right">
                        <?php
                        $idUser = $user['id_user'];

                        $sql_user = mysqli_query($koneksi, "SELECT * FROM tabel_pembelian WHERE id_user = '$idUser' ");
                        $jumlah_user = mysqli_num_rows($sql_user);
                        ?>
                        <span class="badge badge-pill badge-up badge-danger font-small-2 mr-2">
                            <?php echo $jumlah_user; ?>
                        </span>
                        Total Order
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped dataex-html5-selectors">
                            <thead>
                                <tr>
                                    <th>Nama Barang</th>
                                    <th>Foto</th>
                                    <th>Harga</th>
                                    <th>Jumlah</th>
                                    <th>Total di Bayar</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                    <th>Print Nota</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $idUser = $user['id_user'];
                                $ketQuery = "SELECT * FROM tabel_pembelian, tabel_member, tabel_rinci_pembelian, tabel_barang_gambar, tabel_barang WHERE tabel_pembelian.id_user = tabel_member.id_user AND tabel_pembelian.no_faktur_pembelian = tabel_rinci_pembelian.no_faktur_pembelian  AND tabel_pembelian.id_user = '$idUser' AND tabel_barang_gambar.id_brg = tabel_rinci_pembelian.kd_barang AND tabel_barang_gambar.id_brg = tabel_barang.kd_barang ";
                                $executeSat = mysqli_query($koneksi, $ketQuery);
                                while ($b = mysqli_fetch_array($executeSat)) {
                                    // print_r($b);
                                    $e = explode(",", $b['gambar']);

                                ?>
                                <tr>
                                    <td><?php echo $b['nm_barang'] ?></td>
                                    <td> <img src="../img/produk/<?php echo $e[0] ?>" width="50px" height="50px"></td>
                                    <td>Rp.<?php echo number_format($b['harga'], 0, ",", "."); ?></td>
                                    <td><?php echo $b['jumlah'] ?></td>
                                    <td>Rp.<?php echo number_format($b['sub_total_beli'], 0, ",", "."); ?></td>
                                    <td><?php echo $b['status'] ?></td>
                                    <td><?php echo $b['tgl_pembelian'] ?></td>
                                    <td>
                                        <a
                                            href="index.php?menu=nota&faktur=<?php echo $b['no_faktur_pembelian']; ?>&bayar=<?php echo $b['total_biaya']; ?>&tgl=<?php echo $b['tgl_pembelian']; ?>&nama_penerima=<?php echo $b['nm_user']; ?>&alamat=<?php echo $b['alamat_user']; ?>&email=<?php echo $b['email_user']; ?>&noTelp=<?php echo $b['hp']; ?>&nama_merchant=<?php echo $b['nm_toko']; ?>&nama_barang=<?php echo $b['nm_barang']; ?>&jumlah=<?php echo $b['jumlah']; ?>&bayar=<?php echo $b['harga']; ?>&subtotal=<?php echo $b['total_biaya']; ?> ">
                                            <i class="btn btn-primary">Print</i></a>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
            <!-- END: Content-->
        </div>
    </div>
</div>
</div>